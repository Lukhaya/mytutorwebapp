class Tutor extends User{
    constructor(studentId, name, email, phone, marks) {
      super(username, password);
      this.studentId = studentId;
      this.name = name;
      this.email = email;
      this.phone = phone;
      this.marks = marks;
      this.jobAccepted = false;
      this.timeSlots = [];
      this.attendanceRecord = {};
    }
  
    submitApplication(application) {
      // Application is added to the database
      
    }
  
    acceptJob() {
      this.jobAccepted = true;
    }
  
    chooseSlot(timeSlot) {
      this.timeSlots.push(timeSlot);
    }
  
  
    recordAttendance(date) {
    
        this.attendanceRecord[date] = true;
     
      }
}
  
  