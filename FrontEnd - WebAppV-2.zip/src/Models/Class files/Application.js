class Application {
    constructor(applicationId, details, course, tutor) {
      this.applicationId = applicationId;
      this.details = details;
      this.course = course;
      this.tutor = tutor; 
      this.status = "Pending"; 
    }
  
    isSuccessful() {
      return this.details.toLowerCase().includes('accepted');
    }
  
    setStatus(status) {
      this.status = status;
    }
  
    getStatus() {
      return this.status;
    }
  }

 