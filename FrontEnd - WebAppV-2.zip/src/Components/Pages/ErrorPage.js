import React from 'react'

const ErrorPage = () => {
  return (
    <div>
      Could not find page requested
    </div>
  )
}

export default ErrorPage
