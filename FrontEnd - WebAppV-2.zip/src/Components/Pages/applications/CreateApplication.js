import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './styling/applicationform.css';

const CreateApplication = () => {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const courseName = searchParams.get('courseName');
    const courseCode = searchParams.get('courseCode');
    const [description, setDescription] = useState('');
    const accessLink = `http://localhost:3000/applications/accessapplications?courseCode=${courseCode}&courseName=${courseName}`;

    const handleDescriptionChange = (event) => {
        setDescription(event.target.value);
    };

    const handleCopyLink = () => {
        const textField = document.createElement('textarea');
        textField.innerText = accessLink;
        document.body.appendChild(textField);
        textField.select();
        document.execCommand('copy');
        textField.remove();
    };

    return (
        <div>
            <form className="accessapplications-container">
                <label>Department</label>
                <br></br>
                <input type='text' value={courseName+" - "+courseCode} placeholder='' onChange={()=>{}}/>
                
                <br></br>
                <label>Description</label>
                <br></br>
                <textarea type='text' value={description} onChange={handleDescriptionChange} />
            </form>
            <div className="access-link-container">
                <p>Access via:</p>
                <input value={accessLink} readOnly />
                <button onClick={handleCopyLink}>Copy</button>
                <Link
                    to={{
                        pathname: `applications/accessapplications`,
                        state: {
                            courseName: courseName,
                            courseCode: courseCode,
                            description: description,
                        },search: `courseCode=${courseCode}&courseName=${courseName}`
                    }}
                    className="tab"
                >
                    Go to
                </Link>
            </div>
        </div>
    );
};

export default CreateApplication;


