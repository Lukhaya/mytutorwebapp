import React from 'react';
import './styling/applicationform.css';
import { useLocation } from 'react-router-dom';

const ApplicationForm = () => {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const courseName = searchParams.get('courseName');
    const courseCode = searchParams.get('courseCode');

    return (
        <div>
            <div className="form-container">
                <h2>Tutor Application Form</h2>
                <div className="instructions">
                    <h2>Instructions</h2>
                    <p>Please fill out the form below to apply as a tutor for <i><b>{courseName+" - "+courseCode}</b></i>.</p>
                    <p>
                        Kindly note that by submitting this form you consent to your academic record being checked by the
                        department.
                    </p>
                    <br />
                </div>
                <br />
                <form>
                    <label htmlFor="studNo">Student Number</label>
                    <input type="text" id="studNo" name="studNo" required />

                    <label htmlFor="name">Name</label>
                    <input type="text" id="name" name="name" required />

                    <label htmlFor="surname">Surname</label>
                    <input type="text" id="surname" name="surname" required />

                    <label htmlFor="email">Email</label>
                    <input type="email" id="email" name="email" required />

                    <h4>Course</h4>
                    <label htmlFor="course">Course Name</label>
                    <input type="text" id="course" name="course" value={courseName} readOnly />

                    {/* <label htmlFor="courseCode">Course Code</label>
                    <input type="text" id="courseCode" name="courseCode" value={courseCode} readOnly /> */}

                    <label htmlFor="yearOfStudy">Your Year of Study from January</label>
                    <input type="text" id="yearOfStudy" name="yearOfStudy" required />
                    <hr />

                    <button type="submit">Submit</button>
                    <button type="button" onClick={() => console.log('Cancelled')}>Cancel</button>
                </form>
            </div>
        </div>
    );
};

export default ApplicationForm;

